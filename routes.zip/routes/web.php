<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\ProductController;  
use App\Http\Controllers\Api\CategoryController;
use App\Http\Controllers\Api\AuthController; // <-- đặt ở đầu file



// Register (giữ ở gốc: /api/register)
Route::post('/register', [AuthController::class, 'register'])->name('api.register');

// Products
Route::get('/products', [ProductController::class, 'index']);
Route::get('/products/{id}', [ProductController::class, 'show']);

// Categories
Route::get('/categories', [CategoryController::class, 'index']);
Route::get('/categories/{id}', [CategoryController::class, 'show']);
Route::get('/categories/{id}/products', [CategoryController::class, 'products']);
Route::get('/categories/{id}/products', [ProductController::class, 'byCategory']); // trùng URI: giữ nguyên theo yêu cầu

// Admin group (/api/admin/...)
Route::prefix('admin')->group(function () {
Route::get('/products', [ProductController::class, 'adminIndex']);
Route::post('/register', [AuthController::class, 'register']);


Route::post('/register', [AuthController::class, 'register'])->name('api.register'); // thêm


});
